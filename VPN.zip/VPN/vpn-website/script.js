// VPN Website JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    const navActions = document.querySelector('.nav-actions');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            this.classList.toggle('active');
            
            // Create mobile menu if it doesn't exist
            let mobileMenu = document.querySelector('.mobile-menu');
            
            if (!mobileMenu) {
                mobileMenu = document.createElement('div');
                mobileMenu.className = 'mobile-menu';
                mobileMenu.innerHTML = `
                    <ul class="mobile-nav-links">
                        <li><a href="#features">Features</a></li>
                        <li><a href="#pricing">Pricing</a></li>
                        <li><a href="#servers">Servers</a></li>
                        <li><a href="#download">Download</a></li>
                    </ul>
                    <div class="mobile-nav-actions">
                        <a href="#" class="btn btn-secondary btn-full">Log In</a>
                        <a href="#" class="btn btn-primary btn-full">Get Started</a>
                    </div>
                `;
                document.body.appendChild(mobileMenu);
                
                // Add mobile menu styles
                const style = document.createElement('style');
                style.textContent = `
                    .mobile-menu {
                        position: fixed;
                        top: 72px;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background: var(--bg-primary);
                        padding: 24px;
                        z-index: 999;
                        transform: translateX(100%);
                        transition: transform 0.3s ease;
                    }
                    
                    .mobile-menu.active {
                        transform: translateX(0);
                    }
                    
                    .mobile-nav-links {
                        list-style: none;
                        margin-bottom: 24px;
                    }
                    
                    .mobile-nav-links li {
                        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                    }
                    
                    .mobile-nav-links a {
                        display: block;
                        padding: 16px 0;
                        color: var(--text-primary);
                        text-decoration: none;
                        font-size: 1.1rem;
                        font-weight: 500;
                    }
                    
                    .mobile-nav-actions {
                        display: flex;
                        flex-direction: column;
                        gap: 12px;
                    }
                    
                    .mobile-menu-btn.active span:nth-child(1) {
                        transform: rotate(45deg) translate(5px, 5px);
                    }
                    
                    .mobile-menu-btn.active span:nth-child(2) {
                        opacity: 0;
                    }
                    
                    .mobile-menu-btn.active span:nth-child(3) {
                        transform: rotate(-45deg) translate(7px, -6px);
                    }
                `;
                document.head.appendChild(style);
            }
            
            mobileMenu.classList.toggle('active');
        });
    }
    
    // Pricing toggle functionality
    const billingToggle = document.getElementById('billing-toggle');
    const priceAmounts = document.querySelectorAll('.pricing-price .amount');
    const toggleLabels = document.querySelectorAll('.toggle-label');
    
    if (billingToggle) {
        billingToggle.addEventListener('change', function() {
            const isYearly = this.checked;
            
            // Update toggle labels
            toggleLabels.forEach((label, index) => {
                if ((isYearly && index === 1) || (!isYearly && index === 0)) {
                    label.classList.add('active');
                } else {
                    label.classList.remove('active');
                }
            });
            
            // Update prices with animation
            priceAmounts.forEach(amount => {
                const monthlyPrice = amount.dataset.monthly;
                const yearlyPrice = amount.dataset.yearly;
                const newPrice = isYearly ? yearlyPrice : monthlyPrice;
                
                // Animate price change
                amount.style.opacity = '0';
                amount.style.transform = 'translateY(-10px)';
                
                setTimeout(() => {
                    amount.textContent = newPrice;
                    amount.style.opacity = '1';
                    amount.style.transform = 'translateY(0)';
                }, 200);
            });
        });
    }
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            
            if (target) {
                const navHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                const mobileMenu = document.querySelector('.mobile-menu');
                if (mobileMenu && mobileMenu.classList.contains('active')) {
                    mobileMenu.classList.remove('active');
                    mobileMenuBtn.classList.remove('active');
                }
            }
        });
    });
    
    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');
    let lastScroll = 0;
    
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll > 50) {
            navbar.style.background = 'rgba(15, 15, 26, 0.95)';
            navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.3)';
        } else {
            navbar.style.background = 'rgba(15, 15, 26, 0.8)';
            navbar.style.boxShadow = 'none';
        }
        
        lastScroll = currentScroll;
    });
    
    // Intersection Observer for scroll animations
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.feature-card, .pricing-card, .download-card, .section-header').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // Add animation class styles
    const animationStyle = document.createElement('style');
    animationStyle.textContent = `
        .animate-in {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }
    `;
    document.head.appendChild(animationStyle);
    
    // Server location pulse animation
    const serverDots = document.querySelectorAll('.server-dot');
    serverDots.forEach((dot, index) => {
        dot.style.animationDelay = `${index * 0.3}s`;
    });
    
    // Button click handlers for demo
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#' || !href) {
                e.preventDefault();
                
                // Show coming soon popup for demo buttons
                const popup = document.createElement('div');
                popup.className = 'coming-soon-popup';
                popup.innerHTML = `
                    <div class="popup-content">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="12" y1="16" x2="12" y2="12"/>
                            <line x1="12" y1="8" x2="12.01" y2="8"/>
                        </svg>
                        <h3>Coming Soon</h3>
                        <p>This feature is currently under development.</p>
                        <button class="btn btn-primary popup-close">Got it</button>
                    </div>
                `;
                
                // Add popup styles
                const popupStyle = document.createElement('style');
                popupStyle.textContent = `
                    .coming-soon-popup {
                        position: fixed;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background: rgba(0, 0, 0, 0.8);
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        z-index: 10000;
                        opacity: 0;
                        animation: fadeIn 0.3s ease forwards;
                    }
                    
                    @keyframes fadeIn {
                        to { opacity: 1; }
                    }
                    
                    .popup-content {
                        background: var(--bg-card);
                        border: 1px solid rgba(255, 255, 255, 0.1);
                        border-radius: var(--radius-lg);
                        padding: 40px;
                        text-align: center;
                        max-width: 400px;
                        margin: 20px;
                        transform: scale(0.9);
                        animation: scaleIn 0.3s ease forwards;
                    }
                    
                    @keyframes scaleIn {
                        to { transform: scale(1); }
                    }
                    
                    .popup-content svg {
                        width: 48px;
                        height: 48px;
                        color: var(--primary);
                        margin-bottom: 16px;
                    }
                    
                    .popup-content h3 {
                        font-size: 1.5rem;
                        margin-bottom: 8px;
                    }
                    
                    .popup-content p {
                        color: var(--text-secondary);
                        margin-bottom: 24px;
                    }
                `;
                document.head.appendChild(popupStyle);
                
                document.body.appendChild(popup);
                
                // Close popup
                popup.querySelector('.popup-close').addEventListener('click', () => {
                    popup.style.opacity = '0';
                    setTimeout(() => popup.remove(), 300);
                });
                
                popup.addEventListener('click', (e) => {
                    if (e.target === popup) {
                        popup.style.opacity = '0';
                        setTimeout(() => popup.remove(), 300);
                    }
                });
            }
        });
    });
    
    // Counter animation for stats
    function animateCounter(element, target, duration = 2000) {
        let start = 0;
        const increment = target / (duration / 16);
        
        function updateCounter() {
            start += increment;
            if (start < target) {
                element.textContent = Math.floor(start) + (element.textContent.includes('+') ? '+' : '');
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = target + (element.textContent.includes('+') ? '+' : '');
            }
        }
        
        updateCounter();
    }
    
    // Observe stats for counter animation
    const statObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const statNumbers = entry.target.querySelectorAll('.stat-number, .server-stat-number');
                statNumbers.forEach(stat => {
                    const text = stat.textContent;
                    const num = parseInt(text.replace(/\D/g, ''));
                    if (num) {
                        stat.textContent = '0';
                        animateCounter(stat, num);
                    }
                });
                statObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    const heroStats = document.querySelector('.hero-stats');
    const serverStats = document.querySelector('.server-stats');
    
    if (heroStats) statObserver.observe(heroStats);
    if (serverStats) statObserver.observe(serverStats);
    
    console.log('SecureVPN website loaded successfully!');
});
